<?php
define ('WP_API_KEY', 'ff19d6481a7f0a3ce5e1f4e18de93a28');
?>
