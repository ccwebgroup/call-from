
    <?php
    if (!empty($result->error)) {
        
		echo '<div class="error_box">'.$result->error.'</div>';
    } else {
	   if($error!='0')
        echo '<div class="error_box">'.$error.'</div>';
    }
    ?>

<div style="clear:both"></div>
MAKE CONTACT <br>Find neighbors, distant relatives or anyone in the country
