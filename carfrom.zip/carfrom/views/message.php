<div class="message_box">
    <?php
    echo 'No record found';
    ?>
</div>
