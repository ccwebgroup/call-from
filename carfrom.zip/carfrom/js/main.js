function clearData() {
    document.getElementById('phone').value = '';
}